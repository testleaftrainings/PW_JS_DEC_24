import { expect } from "@playwright/test";
import { test } from "./custom-fixture.spec";

test('Test to verify login functionality', async ({page}) => {
    const title = await page.title();
    console.log(`The title of the page is ${title}`);
    await expect(page).toHaveTitle("Home | Salesforce");
    await page.waitForLoadState('domcontentloaded')
await page.locator(".slds-icon-waffle").click()
await page.getByLabel("View All Applications",{exact : true}).click()
//search dashboard and click dashboards
await page.getByPlaceholder("Search apps or items...").fill("Leads")
await page.locator(".slds-truncate mark").click()
await page.waitForLoadState('domcontentloaded')

})