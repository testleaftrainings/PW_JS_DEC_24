import { Page, test, BrowserContext } from "@playwright/test";

export abstract class PlaywrightWrapper {

    readonly page: Page;
    readonly context: BrowserContext;

    constructor(page: Page, context: BrowserContext) {
        this.page = page;
        this.context = context;
    }

    /**
     * Loads the specified URL in the current page context
     * @param url The URL to be loaded
     */
    async loadApp(url: string): Promise<void> {
        await test.step(`The URL ${url} loaded`, async () => {
            await this.page.goto(url);
        })
    }

    async type(locator: string, name: string, data: string): Promise<void> {
        await test.step(`Textbox ${name} filled with ${data}`, async () => {
            await this.page.locator(locator).fill(data);
        })
    }

    async typeAndEnter(locator: string, name: string, data: string): Promise<void> {
        await test.step(`Textbox ${name} filled with ${data}`, async () => {
            await this.page.locator(locator).fill(data);
            await this.page.keyboard.press('Enter');
        })
    }

    async click(locator: string, name: string, type: string): Promise<void> {
        await test.step(`The ${name} ${type} is clicked`, async () => {
            await this.page.waitForSelector(locator, {state: 'attached'});
            await this.page.locator(locator).click();
        })
    }

    abstract getTitle(): Promise<void>;
}