import { Page, BrowserContext } from "@playwright/test";
import { PlaywrightWrapper } from "../utils/playwright";
import { URLConstants } from "../constants/urlConstants";

export class LoginPage extends PlaywrightWrapper{

    static pageUrl = URLConstants.baseURL;

    constructor(page: Page, context: BrowserContext){
        super(page, context);
    }

    async getTitle(): Promise<void> {
        console.log(`The title of the page is ${await this.page.title()}`);  
    }

    async doLogin(username:string, password:string): Promise<void>{
        await this.loadApp(LoginPage.pageUrl);
        await this.type("#username", "Username", username);
        await this.type("#password", "Password", password);
        await this.click("#Login", "Log In", "Button");
    }

}