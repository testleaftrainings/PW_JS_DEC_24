import { test } from "@playwright/test";
import { LoginPage } from "../pages/LoginPage";

test(`Test to verify login functionality`, async ({page, context}) => {
    const login = new LoginPage(page, context);
    await login.doLogin("ranjini.r@testleaf.com", "Qeagle@123");
    await login.getTitle();
})