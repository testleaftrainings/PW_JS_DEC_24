export enum URLConstants {
    baseURL = "https://login.salesforce.com",
    homeURL = "https://testleaf30-dev-ed.develop.lightning.force.com/lightning/setup/SetupOneHome/home"
}