import { TestInfo } from "@playwright/test";
import test from "node:test";
import { createIssue } from "./jiraUtitlityFile";


export async function logDefect(testinfo:TestInfo){  
    if(testinfo.status==="timedOut"|| 'failed'){}
    const summary=`The test ${testinfo.title} is failed`
    const desc= `The test failed due to  ${testinfo.error}`
     createIssue(summary,desc)
}


