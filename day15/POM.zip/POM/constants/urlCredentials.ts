export enum urlConstants{
    baseUrl = "http://leaftaps.com/opentaps/control/main",
    homePageUrl="http://leaftaps.com/opentaps/control/lgin"
}