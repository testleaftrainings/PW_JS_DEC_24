export enum environmetUrl{
    dev="https://www.google.com/dev",
    qa="https://www.google.com/qa"
}
