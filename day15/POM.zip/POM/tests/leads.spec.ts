import { test } from "../customFixtures/fixtures"
import fs from 'fs'
import path from 'path'
import { urlConstants } from "../constants/urlCredentials"
let loginInfo:any[]

test.beforeEach(`Read data for creating the lead`,async()=>{
       loginInfo=JSON.parse(fs.readFileSync(path.join(__dirname, "../constants/login.json"),'utf-8'))

})

test.use({storageState:"./constants/lfLogin.json"})
test(`Verify the lead`,async({hp},testInfo)=>{
    await hp.loadurl(urlConstants.homePageUrl)
    await hp.clickCRMSFA()
    console.log( await hp.verifyTitle())
 })
