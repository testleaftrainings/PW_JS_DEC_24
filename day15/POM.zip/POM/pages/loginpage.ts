import {chromium, Page} from '@playwright/test'
import { urlConstants } from '../../constants/urlCredentials'
export class Login{
    readonly page:Page  //no data is assigned

   constructor(page:Page){
    this.page=page
   }
   
   async loadurl(url:string){
     await this.page.goto(url)
     await this.page.title()
   }

   async enterUsername(user:string){
     await this.page.locator("#username").fill(user)
   }

   async enterPassword(pwd:string){
    await this.page.locator("#password").fill(pwd)
  }  
  async clickLogin(){
    await this.page.locator(".decorativeSubmit").click()
  }

  async storageState(){
    await this.page.context().storageState({path:"./constants/lfLogin.json"})
  }

  async verifyTitle(){
    return await this.page.title()
  }
}


// async function doLogin(){
//     const browser =await chromium.launch({headless:false})
//     const context=await browser.newContext()
//     const page=await context.newPage()
//     const launchap=new LaunchAPP(page)
//     launchap.loadurl()

// }

// doLogin()